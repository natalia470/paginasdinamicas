document.querySelector('tecla_pom');
